package ma.formations.grpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpgrpcserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(TpgrpcserverApplication.class, args);
    }

}
