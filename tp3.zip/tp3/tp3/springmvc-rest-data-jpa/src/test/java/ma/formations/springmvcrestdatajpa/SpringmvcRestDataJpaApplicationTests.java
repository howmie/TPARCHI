package ma.formations.springmvcrestdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcRestDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
