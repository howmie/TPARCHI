package ma.formations.graphql.enums;

public enum TransactionType {
    CREDIT,DEBIT
}
