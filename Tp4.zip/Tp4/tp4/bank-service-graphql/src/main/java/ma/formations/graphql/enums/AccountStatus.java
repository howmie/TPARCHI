package ma.formations.graphql.enums;

public enum AccountStatus {
    OPENED, CLOSED, BLOCKED
}
