@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://presentation.soap.formations.ma/")
package stub;
